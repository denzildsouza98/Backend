package com.icinbank.service;

import com.icinbank.model.Account;
import com.icinbank.response.WithdrawResponse;

public interface AccountService {

	//public Account newAccount(String username);
	public Account deposit(int acc,int amount);
	public WithdrawResponse withdraw(int acc,int amount);
	public void transfer(int saccount,int raccount,int amount);
}
